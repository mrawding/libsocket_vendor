#!/bin/bash

g++ -lsocket++ -o srv server.cpp
g++ -lsocket++ -o cl client.cpp
